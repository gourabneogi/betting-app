import React from "react"
import Routing from "./components/Routing/Routing"

const App = () => {
  return (
    <div className="App">   
      <Routing/> 
    </div>
  )
}

export default App
