import React from 'react';
import Rules from '../../components/Rules/Rules';

const RulesPage = () => {
  return (
    <div>
      <Rules />
    </div>
  );
};

export default RulesPage;
