import React from 'react'
import './LandingPage.css'
const LandingPage = () => {
  return (
    <div className='Container'>
       <div className='wrapper'>
        <div className='title'>NICE1010</div>
        
        <div id="outer">
        <div class="button_slide slide_right">LOGIN </div>
        </div>
       </div>
       
    </div>
  )
}

export default LandingPage
