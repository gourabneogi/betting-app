import React from "react";
import { Routes, Route } from "react-router-dom";
import HomePage from "../../pages/HomePage";
import LandingPage from "../../pages/LandingPage/LandingPage";
import SchedulePage from "../../pages/SchedulePage/SchedulePage";
import LoginPage from "../../pages/LoginPage";
import UpcomingMatchPage from "../../pages/UpcomingMatch/UpcomingMatchesPage";
import TournamentPage from "../../pages/TournamentPage/TournamentPage";
import Password from "../../pages/Password/Password";
import Settings from "../../pages/Settings";
import Rules from "../../pages/RulesPage/Rules";
import GamePage from "../../pages/GamePage/GamePage";
import LedgerPage from "../../pages/LedgerPage/LedgerPage";

const Routing = () => {
  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />

      <Route path="/user/login" element={<LoginPage />} />
      <Route path="/user/upcomming_matches" element={<UpcomingMatchPage />} />

      <Route path="/user/dashboard" element={<HomePage />} />
      <Route path="/user/dashboard/schedule" element={<SchedulePage />} />
      <Route path="/user/dashboard/change_password" element={<Password />} />
      <Route path="/user/dashboard/settings" element={<Settings />} />
      <Route path="/user/dashboard/rules" element={<Rules />} />
      <Route path="/user/games" element={<GamePage />} />
      <Route path="/user/matches/tournaments" element={<TournamentPage />} />
      <Route path="/user/ledger" element={<LedgerPage />} />
    </Routes>
  );
};

export default Routing;
