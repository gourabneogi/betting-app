const table = {
      header: ['DATE', 'ENTRY', 'DEBIT', 'CREDIT', 'BALANCE'],
      body: [
        ['11 Aug 22', 'West Indies vs New Zealand', '15.0','0', '117.0'],
        ['11 Aug 22', 'TeenPatti-T-20 - 10 Aug', '0', '95.0', '-102..0'],
        ['11 Aug 22', 'Birmingham Phoenix vs Southern Brave', '15.0', '0', "-197.0"],
        ['10 Aug 22', 'Zimbabwe vs Bangladesh', '137.0', '0', "-182.0"],
        ['09 Aug 22', 'Bengaluru Blasters vs Hubli Tigers', '15.0', '0', "-45.0"],
        ['09 Aug 22', 'Ireland vs Afghanistan', '15.0', '0', "-30.0"],
        ['05 Aug 22', 'Netherlands vs New Zealand', '15.0', '0', "-15.0"]
      ]
}

export default table;