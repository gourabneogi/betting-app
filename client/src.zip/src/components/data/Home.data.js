const availableButton = [
    "IN PLAY",
    "RULES",
    "LEDGER",
    "PASSWORD",
    "UPCOMING",
    "GAMES",
    "SETTINGS",
    "TOURNAMENT",
  ];

export default availableButton;