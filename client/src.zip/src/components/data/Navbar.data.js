const defaultButton = [
    "HOME",
    "SCHEDULE",
    "LOGOUT"
] 

const userData = {
    name: "BS60503 (Demo)",
    profileImage: "http://nice1010.fun/images/heroic_logo.png",
    profileImageAlt: "Profile Image",
    coins: "883.0"
}

export {defaultButton, userData};

export default userData;